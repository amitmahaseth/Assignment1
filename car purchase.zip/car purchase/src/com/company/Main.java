package com.company;

import com.company.model.Car;
import com.company.model.Customer;

import java.util.*;
import java.util.Scanner;



public class Main {

    public static void main(String[] args) {
        // write your code here
        ArrayList<Customer> list =new ArrayList<Customer>();
        int randId[]=new int[100];
//        ArrayList<Car> carDetails= new ArrayList<Car>();



        System.out.println("Welcome to Car Purchase Utility");
        System.out.println("Login to get access over Car Purchase Utility");
        System.out.println("Enter user id");
        Scanner id = new Scanner(System.in);
        String admin_id=id.nextLine();
        System.out.println("Enter password ");
        String admin_pass=id.nextLine();
        int choice;

        if (admin_id.equals("amit") && admin_pass.equals("amit") ) {
            do{
                System.out.println("Choose option between 1 and 4");
                System.out.println("Press 1 to add a new customer");
                System.out.println("Press 2 to get List of all Customers with their cars");
                System.out.println("Press 3 to get List of individual Customer based on ID,");
                System.out.println("Press 4 to add new car to an existing customer");
                System.out.println("Press 5 to generate prizes for customer");
                System.out.println("Press 6 to exist");
                Scanner input1=new Scanner(System.in);
                choice=input1.nextInt();

                switch (choice){
                    case 1:
                        list.add(new Customer());
                        break;
                    case 2:
                        for (int i=0;i<list.size();i++){
                            System.out.println("Customer Name:"+list.get(i).getinname());
                            for (Car car:list.get(i).getcarList()){
                                System.out.println("Car Id:"+car.getCarID()+",Car name:"+car.getCarName()+",Car Model"+car.getCarModel()+",Car Price:"+car.getCarPrice()+",Car Resale value:"+car.getCarResale());
                            }
                        }
                        break;
                    case 3:
                        for (Customer cc:list){
                            System.out.println("ID:"+cc.getinid()+"\nName:"+cc.getinname());
                        }
                        break;
                    case 4:

                        Scanner check =new Scanner(System.in);
                        System.out.println("Enter customer id");
                        int input=0;
                        if(check.hasNextInt()){
                            input = check.nextInt();
                        }
                        else {
                            //   System.out.println("Invalid Input");
                        }
                        int listlength=list.size();
                        for(int i=0;i<listlength;i++){
                            if (list.get(i).getinid()==input) {
                                Customer customer = list.get(i);
                                ArrayList<Car> cars = customer.getcarList();
                                cars.add(new Car());
                                customer.setCarList(cars);
                                System.out.println("total cars" + cars.size());
                            }
                            else {
                                System.out.println("ID do not exist ");

                            }
                        }
                        break;
                    case 5:
                        System.out.println("Randomly selected users");
                        int i;
                        int listlength1=list.size();
                        for(i=0;i<listlength1;i++) {
                            randId[i]=list.get(i).getinid();

                            //System.out.println(randId[i]);
                        }
                        Random r=new Random();
                        int randomNumber=r.nextInt(list.size());
                        int randomNumber1=r.nextInt(list.size());
                        int randomNumber2=r.nextInt(list.size());
                        System.out.println("Selected ID's:"+list.get(randomNumber).getinid()+","+list.get(randomNumber1).getinid()+","+list.get(randomNumber2).getinid());


                        break;
                    case 6:
                        System.out.println("Thank You for visiting");
                        break;
                    default:
                        System.out.println("enter a valid key");
                }
            }while (choice!=6);

        }
        else {
            System.out.println("you entered Wrong id or password");
        }
    }
}