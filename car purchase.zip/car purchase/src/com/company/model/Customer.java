package com.company.model;

import java.util.ArrayList;
import java.util.Scanner;

public class Customer{
    int inid;
    String inname;
    ArrayList<Car> carList;
    public Customer(){

        Scanner inp=new Scanner(System.in);
        Scanner inpn=new Scanner(System.in);
        System.out.println("Enter Id");
        inid=inpn.nextInt();
        System.out.println("Enter Name");
        inname=inp.nextLine();
        carList=new ArrayList<>();
    }
    public Customer(int inid,String inname,ArrayList<Car> carList){
        this.inid=inid;
        this.inname = inname;
        this.carList=carList;
    }
    public int getinid(){
        return inid;
    }
    public String getinname(){
        return inname;
    }
    public ArrayList<Car> getcarList(){
        return carList;
    }
    public void setCarList(final ArrayList<Car> carList){
        this.carList=carList;
    }

}
