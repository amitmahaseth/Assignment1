package com.company.model;

import java.util.Scanner;

public class Car{
    String carName;
    int carID;
    int carPrice;
    String carModel;

    public Car(int carId, String carName,String carModel,int carPrice){
        this.carID=carId;
        this.carModel=carModel;
        this.carName=carName;
        this.carPrice=carPrice;
    }
    public Car(){
        Scanner cn=new Scanner(System.in);
        Scanner ci=new Scanner(System.in);
        System.out.println("Enter car name:-  you can only enter'Hyundai','Toyota','Maruti' ");
        carName =cn.nextLine();
        System.out.println("Enter car price");
        carPrice=ci.nextInt();
        System.out.println("Enter car model");
        carModel=cn.nextLine();
        System.out.println("Enter car ID");
        carID=ci.nextInt();
    }
    public int getCarID(){return carID;}
    public int getCarPrice(){return carPrice;}
    public String getCarName(){return carName;}
    public String getCarModel(){return carModel;}
    public double getCarResale(){
        if (getCarName().equals("hyundai")){
            return carPrice*0.4;
        }
        else if(getCarName().equals("toyota")){
            return carPrice*0.8;
        }
        else if(getCarName().equals("maruti")){
            return carPrice*0.6;
        }
        else {
            return 0;
        }
    }
}